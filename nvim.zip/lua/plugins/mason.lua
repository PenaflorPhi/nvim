return {
	{
		"neovim/nvim-lspconfig",
		dependencies = { "mason-org/mason.nvim", "mason-org/mason-lspconfig.nvim" },
		config = function()
			require("lspconfig").clangd.setup({
				on_attach = function(client, bufnr)
					vim.notify("clangd attached to " .. bufnr)
					require("core.keymaps").on_attach(client, bufnr)
				end,
			})

			for _, buf in ipairs(vim.api.nvim_list_bufs()) do
				if vim.bo[buf].filetype == "c" then
					vim.lsp.buf_attach_client(buf, vim.lsp.get_clients({ name = "clangd" })[1].id)
				end
			end
		end,
	},
}
