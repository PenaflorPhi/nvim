#include <stdio.h>

int main(void) {
  int x = 1;
  return 0;
}
