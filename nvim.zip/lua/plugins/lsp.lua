return {
	{
		"neovim/nvim-lspconfig",
		dependencies = { "mason-org/mason.nvim", "mason-org/mason-lspconfig.nvim" },
		event = { "BufReadPre", "BufNewFile" },
		config = function()
			require("lspconfig").clangd.setup({
				on_attach = function(client, bufnr)
					vim.notify("clangd attached to " .. bufnr)
					require("core.keymaps").on_attach(client, bufnr)
				end,
			})
		end,
	},
}
