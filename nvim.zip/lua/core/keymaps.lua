-- Keymaps
vim.g.mapleader = " "
vim.g.maplocalleader = " "

local default_opts = { noremap = true, silent = true }
local function map(mode, lhs, rhs, desc, opts)
	local o = opts and vim.tbl_extend("force", default_opts, opts) or default_opts
	if desc then
		o.desc = desc
	end
	vim.keymap.set(mode, lhs, rhs, o)
end

local function toggle_explorer()
	local ok, api = pcall(require, "nvim-tree.api")
	if ok then
		api.tree.toggle()
	else
		vim.cmd("Ex")
	end
end

local function toggle_opt(optname)
	vim.opt[optname] = not vim.opt[optname]:get()
end

-- File Explorer
map("n", "<leader>e", toggle_explorer, "File explorer")

-- Windows
map("n", "<C-Left>", "<C-w>h", "Go to left window")
map("n", "<C-Down>", "<C-w>j", "Go to below window")
map("n", "<C-Up>", "<C-w>k", "Go to above window")
map("n", "<C-Right>", "<C-w>l", "Go to right window")
map("n", "<A-Left>", "<C-w><", "Shrink width")
map("n", "<A-Right>", "<C-w>>", "Grow width")
map("n", "<A-Up>", "<C-w>+", "Grow height")
map("n", "<A-Down>", "<C-w>-", "Shrink height")
map("n", "<leader>=", "<C-w>=", "Equalize splits")

-- Editing
map("n", "<C-d>", "<C-d>zz", "Half-page down, centered")
map("n", "<C-u>", "<C-u>zz", "Half-page up, centered")
map("n", "<leader>/", ":nohlsearch<CR>", "Clear search highlight")
map("v", "<Tab>", ">gv", "Indent selection")
map("v", "<S-Tab>", "<gv", "Unindent selection")
map("v", "<", "<gv", "Unindent selection")
map("v", ">", ">gv", "Indent selection")
map("n", "<A-j>", ":m .+1<CR>==", "Move line down")
map("n", "<A-k>", ":m .-2<CR>==", "Move line up")
map("i", "<A-j>", "<Esc>:m .+1<CR>==gi", "Move line down")
map("i", "<A-k>", "<Esc>:m .-2<CR>==gi", "Move line up")
map("v", "<A-j>", ":m '>+1<CR>gv=gv", "Move block down")
map("v", "<A-k>", ":m '<-2<CR>gv=gv", "Move block up")
map("n", "Y", "y$", "Yank to end of line")

-- Spelling
map("n", "<leader>sn", "]s", "Next misspelling")
map("n", "<leader>sp", "[s", "Prev misspelling")
map("n", "<leader>ss", "z=", "Suggestions")
map("n", "<leader>sa", "zg", "Add word")
map("n", "<leader>su", "zug", "Undo add")
map("n", "<leader>st", function()
	toggle_opt("spell")
end, "Toggle spell")

-- Search
map("n", "n", "nzzzv", "Next search result centered")
map("n", "N", "Nzzzv", "Prev search result centered")

-- Telescope
local function T(picker, opts)
	local ok, tb = pcall(require, "telescope.builtin")
	if not ok then
		vim.notify("Telescope not installed", vim.log.levels.WARN)
		return
	end
	tb[picker](opts or {})
end

map("n", "<leader>tf", function()
	T("find_files")
end, "Telescope: Find files")
map("n", "<leader>tg", function()
	T("live_grep")
end, "Telescope: Live grep")
map("n", "<leader>tb", function()
	T("buffers")
end, "Telescope: Buffers")
map("n", "<leader>th", function()
	T("help_tags")
end, "Telescope: Help tags")
map("n", "<leader>tr", function()
	T("resume")
end, "Telescope: Resume")
map("n", "<leader>tc", function()
	T("commands")
end, "Telescope: Commands")
map("n", "<leader>ts", function()
	T("lsp_document_symbols")
end, "Telescope: Doc symbols")
map("n", "<leader>tw", function()
	T("lsp_dynamic_workspace_symbols")
end, "Telescope: WS symbols")
map("n", "<leader>tk", function()
	T("keymaps")
end, "Telescope: Keymaps")

-- Diagnostics (global — work without LSP too)
local diag_float = { border = "rounded", source = "if_many" }
map("n", "]d", function()
	vim.diagnostic.goto_next({ float = diag_float })
end, "Next diagnostic")
map("n", "[d", function()
	vim.diagnostic.goto_prev({ float = diag_float })
end, "Prev diagnostic")
map("n", "<leader>N", function()
	vim.diagnostic.goto_prev({ float = diag_float })
end, "Diagnostics: Previous")
map("n", "<leader>n", function()
	vim.diagnostic.goto_next({ float = diag_float })
end, "Diagnostics: Next")
map("n", "<leader>de", vim.diagnostic.open_float, "Line diagnostics")
map("n", "<leader>dq", vim.diagnostic.setloclist, "Diagnostics to loclist")

-- Copilot
vim.g.copilot_no_tab_map = true
vim.g.copilot_assume_mapped = true
map("i", "<leader><Tab>", 'copilot#Accept("\\<CR>")', "Copilot: Accept", { expr = true, replace_keycodes = false })
map("i", "<C-j>", "copilot#Suggest()", "Copilot: Suggest", { expr = true })
map("i", "<C-n>", "copilot#Next()", "Copilot: Next", { expr = true })
map("i", "<C-p>", "copilot#Previous()", "Copilot: Previous", { expr = true })
map("i", "<C-]>", "copilot#Dismiss()", "Copilot: Dismiss", { expr = true })

-- LSP on_attach (called from lspconfig plugin spec)
local M = {}
M.on_attach = function(client, bufnr)
	local opts = { buffer = bufnr, noremap = true, silent = true }
	vim.keymap.set("n", "<C-k>", vim.lsp.buf.hover, vim.tbl_extend("force", opts, { desc = "LSP: Hover" }))
	vim.keymap.set(
		"i",
		"<C-k>",
		vim.lsp.buf.signature_help,
		vim.tbl_extend("force", opts, { desc = "LSP: Signature help" })
	)
	vim.keymap.set("n", "gd", vim.lsp.buf.definition, vim.tbl_extend("force", opts, { desc = "LSP: Go to definition" }))
	vim.keymap.set("n", "gr", vim.lsp.buf.references, vim.tbl_extend("force", opts, { desc = "LSP: References" }))
	vim.keymap.set("n", "<leader>rn", vim.lsp.buf.rename, vim.tbl_extend("force", opts, { desc = "LSP: Rename" }))
	vim.keymap.set(
		{ "n", "v" },
		"<leader>a",
		vim.lsp.buf.code_action,
		vim.tbl_extend("force", opts, { desc = "LSP: Code action" })
	)
end

map("n", "<leader>c", function()
	local buf = vim.api.nvim_get_current_buf()
	-- if bufferline is loaded, use its close to preserve layout
	local ok, bufferline = pcall(require, "bufferline")
	if ok then
		vim.cmd("bdelete " .. buf)
	else
		vim.cmd("bdelete")
	end
end, "Close buffer")

return M
