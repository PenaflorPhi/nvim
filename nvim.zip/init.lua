require("core.options")
require("core.keymaps")
require("core.autocmds")
require("core.lazy")

vim.cmd.colorscheme("tokyonight-night")
